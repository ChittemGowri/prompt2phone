// ─── Core Types ────────────────────────────────────────────────────────────────

export interface DeviceInfo {
  id: string;
  model: string;
  androidVersion: string;
  status: 'online' | 'offline' | 'unauthorized';
}

export interface ActionStep {
  type: ActionType;
  description: string;
  params: Record<string, unknown>;
}

export type ActionType =
  | 'tap'
  | 'swipe'
  | 'type_text'
  | 'press_key'
  | 'launch_app'
  | 'scroll'
  | 'screenshot'
  | 'wait'
  | 'back'
  | 'home'
  | 'find_element';

export interface ExecutionPlan {
  instruction: string;
  steps: ActionStep[];
  estimatedDuration: number; // ms
}

export interface ExecutionResult {
  success: boolean;
  stepsCompleted: number;
  totalSteps: number;
  error?: string;
  screenshot?: string; // base64
  duration: number; // ms
}

export interface TapParams {
  x: number;
  y: number;
}

export interface SwipeParams {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  duration?: number;
}

export interface TypeTextParams {
  text: string;
}

export interface LaunchAppParams {
  packageName: string;
  activityName?: string;
}

export interface PressKeyParams {
  keyCode: number | string;
}

export interface WaitParams {
  duration: number;
}

export interface ScrollParams {
  direction: 'up' | 'down' | 'left' | 'right';
  amount?: number;
}

// ─── Config Types ───────────────────────────────────────────────────────────────

export interface SMAConfig {
  anthropicApiKey: string;
  model?: string;
  deviceId?: string;
  adbPath?: string;
  verbose?: boolean;
  screenshotOnError?: boolean;
}

// ─── AI Types ───────────────────────────────────────────────────────────────────

export interface AIMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface ParsedAIResponse {
  plan: ExecutionPlan;
  explanation: string;
}
